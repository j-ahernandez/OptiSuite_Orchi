<?php echo (new \Orchid\Icons\Icon($html))->setAttributes($data); ?>

<?php /**PATH C:\xampp\htdocs\Laravel\OptiSuite\vendor\orchid\blade-icons\src/../views//icon.blade.php ENDPATH**/ ?>